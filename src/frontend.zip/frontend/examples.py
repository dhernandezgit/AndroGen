import os

examples_background = [
    [["resources/examples/predefined_background_file/VISEM.png"], 0.1, 0.1, False, False],
    [[os.path.join("resources/examples/predefined_background/VISEM", p) for p in os.listdir("resources/examples/predefined_background/VISEM")], 0.1, 0.1, True, True],
    [["resources/examples/predefined_background_file/SVIA.png"], 0.1, 0.1, False, False],
    [[os.path.join("resources/examples/predefined_background/SVIA", p) for p in os.listdir("resources/examples/predefined_background/SVIA")], 0.1, 0.1, True, True],
    [["resources/examples/predefined_background_file/BOSS.png"], 0.1, 0.1, False, False],
    [[os.path.join("resources/examples/predefined_background/BOSS", p) for p in os.listdir("resources/examples/predefined_background/BOSS")], 0.1, 0.1, True, True],
]
examples_background_names = ["VISEM single background", "VISEM 20 images", "SVIA single background", "SVIA 20 images", "BOSS single background", "BOSS 20 images"]

examples_style = [
    [{
        "image": "resources/examples/predefined_background/VISEM/22_frame_16.jpg",
        "boxes": [
        {
            "xmin": 223,
            "ymin": 253,
            "xmax": 243,
            "ymax": 273,
            "label": "Spermatozoon head",
            "color": (255, 128, 0)
        }]
    },
    "rgba(212, 212, 212, 1)",
    "rgba(42, 42, 42, 1)",
    "rgba(54, 54, 54, 1)",
    "rgba(44, 44, 44, 1)",
    "rgba(20, 16, 31, 1)",
    "rgba(184, 181, 181, 1)",
    "rgba(113, 104, 97, 1)",
    3.5,
    -8,
    3,
    100
],
    [{
        "image": "resources/examples/predefined_background/SVIA/S_0068_0016.png",
        "boxes": [
        {
            "xmin": 209,
            "ymin": 169,
            "xmax": 229,
            "ymax": 189,
            "label": "Spermatozoon head",
            "color": (255, 128, 0)
        }]
    },
    "rgba(85, 85, 85, 1)",
    "rgba(86, 88, 82, 1)",
    "rgba(86, 88, 82, 1)",
    "rgba(86, 88, 82, 1)",
    "rgba(86, 88, 82, 1)",
    "rgba(132, 132, 131, 1)",
    "rgba(200, 200, 194, 1)",
    3.5,
    -8,
    2.5,
    100
],
    [{
        "image": "resources/examples/predefined_background/BOSS/test-1-19_field_6_0.png",
        "boxes": [
        {
            "xmin": 372,
            "ymin": 503,
            "xmax": 392,
            "ymax": 523,
            "label": "Spermatozoon head",
            "color": (255, 128, 0)
        }]
    },
    "rgba(228, 228, 228, 1)",
    "rgba(150, 150, 150, 1)",
    "rgba(95, 95, 95, 1)",
    "rgba(228, 228, 228, 1)",
    "rgba(228, 228, 228, 1)",
    "rgba(35, 35, 35, 1)",
    "rgba(35, 35, 35, 1)",
    1.4,
    -2,
    4,
    100
],
]
examples_style_names = ["VISEM", "SVIA", "BOSS"]