import os
import sys
sys.path.append(os.path.abspath('.'))

import gradio as gr
from gradio_rangeslider import RangeSlider
from gradio_image_annotation import image_annotator
import numpy as np
import time
import cv2
import shutil
import json
import random
import configparser

from src.backend.SpermatozoonFactory import SpermatozoonFactory
from src.backend.DebrisFactory import DebrisFactory
from src.backend.BackgroundGenerator import BackgroundGenerator
from src.backend.ConfigParser import SequenceConfig, DatasetConfig
from src.backend.SequenceGenerator import SequenceGenerator
from src.backend.DatasetMaker import DatasetMaker
from src.backend.ImageAugmentor import ImageAugmentor
from src.backend.utils import save_gif, read_json, update_json

from src.frontend.parameterSelectionUtils import *
from src.frontend.styleAdjustmentUtils import *
from src.frontend.dataGenerationUtils import *
from src.frontend.examples import *

class App:
    def __init__(self, config_path):
        self.config_path = config_path
        
        config = configparser.ConfigParser()
        config.read(self.config_path)
        self.species_path = config['Paths']['species_path']
        self.test_sequence_path = config['Paths']['test_sequence_path']
        self.test_gif_path = config['Paths']['test_gif_path']
        self.species_dict_path = config['Paths']['species_dict_path']
        self.style_config_path = config['Paths']['style_config_path']
        self.debris_dict_path = config['Paths']['debris_dict_path']
        
        self.sequence_config = SequenceConfig(config_path)
        self.dataset_config = DatasetConfig(config_path)
        
        self.bgg = BackgroundGenerator()
        paths = "/home/daniel/Documents/Projects/Kubus/Morfología/Data/vids_processed"
        image_paths = os.listdir(paths)
        image_paths = [os.path.join(paths, p) for p in image_paths]
        self.bgg.setGenerationMethod('list', paths=image_paths)
        self.sf = SpermatozoonFactory(self.species_dict_path, self.style_config_path)
        self.df = DebrisFactory(self.debris_dict_path, self.style_config_path)

        #Initialize variables for Style Adjustment tab
        set_species_path(self.species_path)
        self.species_names = species_update_list()
        self.starting_specie = self.species_names[0]
        set_species_dict(read_json(os.path.join(self.species_path, f"{self.starting_specie}.json")))
        
        #Initialize variables for Parameter Selection tab
        
        
        #Initialize variables for Data Generation tab
        self.initialize_gradio_structure()
        
    def _pass_value(self, value):
        return value
    
    def _update_augmentation(self, contrast, brightness, horizontal_flip, vertical_flip):
        params = {}
        params['Sequence.augmentation'] = {}
        params['Sequence.augmentation']['contrast'] = contrast
        params['Sequence.augmentation']['brightness'] = brightness
        params['Sequence.augmentation']['horizontal_flip'] = horizontal_flip
        params['Sequence.augmentation']['vertical_flip'] = vertical_flip 
        self.sequence_config.writeParameters(params)
        return [contrast, brightness, horizontal_flip, vertical_flip]
        
        
    def _update_colors(self, head_color, neck_color, tail_color, droplet_color, debris_color, shadow_start_color, shadow_end_color, scale, shadow_offset, shadow_scale, n_points):
        params = read_json(self.style_config_path)
        params['color']['head']['r'] = process_color(head_color)[0]
        params['color']['head']['g'] = process_color(head_color)[1]
        params['color']['head']['b'] = process_color(head_color)[2]
        params['color']['neck']['r'] = process_color(neck_color)[0]
        params['color']['neck']['g'] = process_color(neck_color)[1]
        params['color']['neck']['b'] = process_color(neck_color)[2]
        params['color']['tail']['r'] = process_color(tail_color)[0]
        params['color']['tail']['g'] = process_color(tail_color)[1]
        params['color']['tail']['b'] = process_color(tail_color)[2]
        params['color']['droplet']['r'] = process_color(droplet_color)[0]
        params['color']['droplet']['g'] = process_color(droplet_color)[1]
        params['color']['droplet']['b'] = process_color(droplet_color)[2]
        params['color']['debris']['r'] = process_color(debris_color)[0]
        params['color']['debris']['g'] = process_color(debris_color)[1]
        params['color']['debris']['b'] = process_color(debris_color)[2]
        params['color']['shadow_start']['r'] = process_color(shadow_start_color)[0]
        params['color']['shadow_start']['g'] = process_color(shadow_start_color)[1]
        params['color']['shadow_start']['b'] = process_color(shadow_start_color)[2]
        params['color']['shadow_end']['r'] = process_color(shadow_end_color)[0]
        params['color']['shadow_end']['g'] = process_color(shadow_end_color)[1]
        params['color']['shadow_end']['b'] = process_color(shadow_end_color)[2]
        params['color']['debris_shadow_start']['r'] = process_color(shadow_start_color)[0]
        params['color']['debris_shadow_start']['g'] = process_color(shadow_start_color)[1]
        params['color']['debris_shadow_start']['b'] = process_color(shadow_start_color)[2]
        params['color']['debris_shadow_end']['r'] = process_color(shadow_end_color)[0]
        params['color']['debris_shadow_end']['g'] = process_color(shadow_end_color)[1]        
        params['color']['debris_shadow_end']['b'] = process_color(shadow_end_color)[2]
        params['scale'] = scale
        params['shadow_offset'] = shadow_offset
        params['shadow_starting_scale'] = max(int(shadow_scale/4), 1)
        params['shadow_ending_scale'] = shadow_scale
        params['debris_shadow_offset'] = shadow_offset
        params['debris_shadow_starting_scale'] = max(int(shadow_scale/2), 1)
        params['debris_shadow_ending_scale'] = shadow_scale
        params['n_points'] = n_points
        update_json(self.style_config_path, params)
        self.sf = SpermatozoonFactory(self.species_dict_path, self.style_config_path)
        self.df = DebrisFactory(self.debris_dict_path, self.style_config_path)
        return [head_color, neck_color, tail_color, droplet_color, debris_color, shadow_start_color, shadow_end_color, scale, shadow_offset, shadow_scale, n_points]
        
    def _update_config(self, name, value):
        if isinstance(value, tuple):  # Check if value is a tuple
            value = list(value)
        
        params = {}
        params["Sequence.quantities"] = {}
        params["Sequence.quantities"][name] = str(value)
        self.sequence_config.writeParameters(params)
        
        
    def _update_background_generator(self, images, contrast, brightness, horizontal_flip, vertical_flip, n_images_out=9):
        self.sequence_config.update()
        if len(images) < 1:  # Check if the list of images is empty
            raise gr.Error("Please select at least one image.")
        elif len(images) == 1:  # If there is only one image, use it as the background
            self.bgg.setGenerationMethod('single', single_image_path=images[0])
            bg = self.bgg.getBackground(resolution=self.sequence_config.getParameters()['Sequence.resolution']['resolution'])
            ia = ImageAugmentor(contrast=contrast, brightness=brightness, horizontal_flip=horizontal_flip, vertical_flip=vertical_flip)
            return ia.augment(bg, num_images=n_images_out)
        else:  # If there are multiple images, use them as a background
            self.bgg.setGenerationMethod('list', paths=images)
            ia = ImageAugmentor(contrast=contrast, brightness=brightness, horizontal_flip=horizontal_flip, vertical_flip=vertical_flip)
            images_out = []
            for n in range(n_images_out):
                bg = self.bgg.getBackground(resolution=self.sequence_config.getParameters()['Sequence.resolution']['resolution'])
                images_out.append(ia.augment(bg, num_images=1)[0])
            return images_out
    
    def _generate_sequence(self, n_frames, extra_images = 9, remove_old=True):
        if remove_old:
            if os.path.isdir(self.test_sequence_path):
                shutil.rmtree(self.test_sequence_path)
            if os.path.exists(self.test_gif_path):
                os.remove(self.test_gif_path)
        params = self.sequence_config.getParameters()['Sequence.augmentation']
        ia = ImageAugmentor(contrast=params['contrast'], brightness=params['brightness'], horizontal_flip=params['horizontal_flip'], vertical_flip=params['vertical_flip'])
        sg = SequenceGenerator(n_frames, self.sequence_config, self.sf, self.df, self.bgg)
        sg.generate_sequence(output_dir=self.test_sequence_path)
        save_gif(self.test_sequence_path, 0)
        if n_frames > 1:
            return [self.test_gif_path] + [os.path.join(self.test_sequence_path, p) for p in np.random.choice(os.listdir(self.test_sequence_path), extra_images)]
        else:
            return [os.path.join(self.test_sequence_path, p) for p in os.listdir(self.test_sequence_path)]

    def _generate_dataset(self, dataset_name, save_folder, n_sequences, n_frames_sequence, seed):
        #np.random.seed(int(seed))
        #random.seed(int(seed))
        params = self.sequence_config.getParameters()['Sequence.augmentation']
        ia = ImageAugmentor(contrast=params['contrast'], brightness=params['brightness'], horizontal_flip=params['horizontal_flip'], vertical_flip=params['vertical_flip'])
        dm = DatasetMaker(num_sequences=int(n_sequences), num_frames=int(n_frames_sequence), sequence_config=self.sequence_config, sf=self.sf, df=self.df, bgg=self.bgg, output_dir=os.path.join(save_folder, dataset_name), image_augmentor=ia)
        yield from dm.generate_dataset()
        
    def initialize_gradio_structure(self):
        custom_css = """
        #file-uploader {
            max-height: 150px; /* Adjust the height as needed */
            overflow-y: auto; /* Enable scrolling if content overflows */
            border: 1px solid #ccc; /* Optional: Add a border for better visibility */
            padding: 5px; /* Optional: Add some padding for better spacing */
        }

        #examples-container {
            background-color: #d67f29; /* Coral orange background for Examples */
            padding: 5px;
        }
        """
        #Initialize app structure
        self.app = None
        
        
        with gr.Blocks(css=custom_css, fill_width=True, fill_height=True, theme=gr.themes.Soft()) as self.app:
            #Style Adjustment
            params = self.sequence_config.getParameters()['Sequence.augmentation']
            contrast_variation_state = gr.State(value=params['contrast'])
            brightness_variation_state = gr.State(value=params['brightness'])
            horizontal_flip_checkbox_state = gr.State(value=params['horizontal_flip'])
            vertical_flip_checkbox_state = gr.State(value=params['vertical_flip'])
            
            params = read_json(self.style_config_path)
            spermatozoon_head_color_state = gr.State(value=f"rgba({params['color']['head']['r']}, {params['color']['head']['g']}, {params['color']['head']['b']}, 1)")
            spermatozoon_neck_color_state = gr.State(value=f"rgba({params['color']['neck']['r']}, {params['color']['neck']['g']}, {params['color']['neck']['b']}, 1)")
            spermatozoon_tail_color_state = gr.State(value=f"rgba({params['color']['tail']['r']}, {params['color']['tail']['g']}, {params['color']['tail']['b']}, 1)")
            spermatozoon_droplet_color_state = gr.State(value=f"rgba({params['color']['droplet']['r']}, {params['color']['droplet']['g']}, {params['color']['droplet']['b']}, 1)")
            debris_color_state = gr.State(value=f"rgba({params['color']['debris']['r']}, {params['color']['debris']['g']}, {params['color']['debris']['b']}, 1)")
            shadow_start_color_state = gr.State(value=f"rgba({params['color']['shadow_start']['r']}, {params['color']['shadow_start']['g']}, {params['color']['shadow_start']['b']}, 1)")
            shadow_end_color_state = gr.State(value=f"rgba({params['color']['shadow_end']['r']}, {params['color']['shadow_end']['g']}, {params['color']['shadow_end']['b']}, 1)")
            spermatozoon_scale_slider_state = gr.State(value=2.35)
            shadow_offset_slider_state = gr.State(value=0.0)
            shadow_scale_slider_state = gr.State(value=0.0)
            n_points_render_slider_state = gr.State(value=100)  
            
            one_state = gr.State(value=1)
        
            with gr.Accordion("AndroGen", open=True):
                gr.Markdown("Welcome to the AndroGen app. This app generates synthetic images of sperm cells to train Deep Learning models without real labelled data. Please navigate through the menus in order to get the best results or test the app in the Data Generation section. Please refer to the original paper to get a detailed explanation of this app.")
                
            with gr.Accordion("Style Adjustment", open=False):
                with gr.Row():
                    with gr.Group():
                        gr.Markdown(" ### Background")
                        with gr.Column():
                            input_images = gr.File(label="Upload Images", file_types=["image"], type="filepath", file_count="multiple", elem_id="file-uploader")
                            background_button = gr.Button("Generate test backgrounds")
                            background_output = gr.Gallery(label="Sample backgrounds", preview=True, selected_index=0, interactive=False)
                        #with gr.Tab("Fixed background"):
                        #    gr.Interface(
                        #        fn=process_image,
                        #        inputs=gr.Image(type="numpy", label="Upload your image"),
                        #        outputs="image",
                        #        examples=["/home/daniel/Documents/Projects/Tesis/Kubus/datasets/GT/gt/field_1/0.png",
                        #                "/home/daniel/Documents/Projects/Tesis/Kubus/datasets/SVIA/Frames from original videos/S_0001/S_0001_0001.png",
                        #                "/home/daniel/Documents/Projects/Tesis/Kubus/datasets/VISEM-Tracking/VISEM_Tracking_Train_v4/Train/11/images/11_frame_0.jpg"]  # Ejemplos de imagen
                        #    )
                        #with gr.Tab("Dynamic background"):
                        #    gr.Interface(
                        #        fn=process_folder,
                        #        inputs=gr.File(type="filepath", label="Upload your image folder"),
                        #        outputs=gr.Image(type="numpy", label="Upload your image"),
                        #        #examples=["spermatozoon/fondos.zip"]  # Ejemplo de archivo ZIP
                        #    )
                        examples_background_item = gr.Examples(examples_background, elem_id="examples-container", label="Background generation examples", example_labels=examples_background_names, inputs=[input_images, contrast_variation_state, brightness_variation_state, horizontal_flip_checkbox_state, vertical_flip_checkbox_state], outputs=[background_output], fn=self._update_background_generator, examples_per_page=6)
                        with gr.Accordion("Image augmentation settings", open=False):
                            gr.Markdown(" ### Other parameters")
                            contrast_variation = gr.Slider(label="Contrast deviation", minimum=0.0, maximum=1.0, value=contrast_variation_state.value)
                            brightness_variation = gr.Slider(label="Brightness deviation", minimum=0.0, maximum=1.0, value=brightness_variation_state.value)
                            #blur_variation = gr.Slider(label="Max blur", minimum=0.0, maximum=51.0, value=5)
                            with gr.Row():
                                horizontal_flip_checkbox = gr.Checkbox(label="Horizontal flip", value=horizontal_flip_checkbox_state.value)
                                vertical_flip_checkbox = gr.Checkbox(label="Vertical flip", value=vertical_flip_checkbox_state.value)
                        background_button.click(self._update_background_generator, [input_images, contrast_variation, brightness_variation, horizontal_flip_checkbox, vertical_flip_checkbox], [background_output])
                        input_images.change(self._update_background_generator, [input_images, contrast_variation, brightness_variation, horizontal_flip_checkbox, vertical_flip_checkbox], [background_output])
                        contrast_variation.change(self._pass_value, inputs=contrast_variation, outputs=contrast_variation_state)
                        contrast_variation_state.change(self._update_augmentation, [contrast_variation_state, brightness_variation_state, horizontal_flip_checkbox_state, vertical_flip_checkbox_state], [contrast_variation, brightness_variation, horizontal_flip_checkbox, vertical_flip_checkbox])
                        brightness_variation.change(self._pass_value, inputs=brightness_variation, outputs=brightness_variation_state)
                        brightness_variation_state.change(self._update_augmentation, [contrast_variation_state, brightness_variation_state, horizontal_flip_checkbox_state, vertical_flip_checkbox_state], [contrast_variation, brightness_variation, horizontal_flip_checkbox, vertical_flip_checkbox])
                        horizontal_flip_checkbox.change(self._pass_value, inputs=horizontal_flip_checkbox, outputs=horizontal_flip_checkbox_state)
                        horizontal_flip_checkbox_state.change(self._update_augmentation, [contrast_variation_state, brightness_variation_state, horizontal_flip_checkbox_state, vertical_flip_checkbox_state], [contrast_variation, brightness_variation, horizontal_flip_checkbox, vertical_flip_checkbox])
                        vertical_flip_checkbox.change(self._pass_value, inputs=vertical_flip_checkbox, outputs=vertical_flip_checkbox_state)
                        vertical_flip_checkbox_state.change(self._update_augmentation, [contrast_variation_state, brightness_variation_state, horizontal_flip_checkbox_state, vertical_flip_checkbox_state], [contrast_variation, brightness_variation, horizontal_flip_checkbox, vertical_flip_checkbox])    
                        # Crear la interfaz con pestañas
                        #with gr.TabbedInterface([fixed_background, fixed_background], 
                        #                        ["Fixed background", "Dynamic background"]) as background_interface:
                        #    background_interface.launch()
                    with gr.Group():
                        gr.Markdown(" ### Sperm cells")
                        spermatozoon_image_annotator = image_annotator(
                            image_type="numpy",
                            disable_edit_boxes=True,
                            single_box=True,
                            label="Upload your reference image and select a single sperm cell head"
                        )
                        # gr.Examples([{
                        #             "image": "/home/daniel/Documents/Projects/Tesis/Kubus/datasets/GT/gt/field_1/0.png",
                        #             "boxes": [
                        #             {
                        #                 "xmin": 0,
                        #                 "ymin": 0,
                        #                 "xmax": 200,
                        #                 "ymax": 200,
                        #                 "label": "Spermatozoon",
                        #                 "color": (255, 128, 0)
                        #             }]
                        #             },
                        #             {
                        #             "image": "/home/daniel/Documents/Projects/Tesis/Kubus/datasets/SVIA/Frames from original videos/S_0001/S_0001_0001.png",
                        #             "boxes": [
                        #             {
                        #                 "xmin": 0,
                        #                 "ymin": 0,
                        #                 "xmax": 200,
                        #                 "ymax": 200,
                        #                 "label": "Spermatozoon",
                        #                 "color": (255, 128, 0)
                        #             }]
                        #             },
                        #             {
                        #             "image": "/home/daniel/Documents/Projects/Tesis/Kubus/datasets/VISEM-Tracking/VISEM_Tracking_Train_v4/Train/11/images/11_frame_0.jpg",
                        #             "boxes": [
                        #             {
                        #                 "xmin": 0,
                        #                 "ymin": 0,
                        #                 "xmax": 200,
                        #                 "ymax": 200,
                        #                 "label": "Spermatozoon",
                        #                 "color": (255, 128, 0)
                        #             }]
                        #             }
                        #             ],
                        #             spermatozoon_image)  # Ejemplos de imagen
                        extract_button = gr.Button("Extract parameters")
                        examples_style_item = gr.Examples(examples_style, elem_id="examples-container", label="Style adjustment examples", example_labels=examples_style_names, inputs=[spermatozoon_image_annotator, spermatozoon_head_color_state, spermatozoon_neck_color_state, spermatozoon_tail_color_state, spermatozoon_droplet_color_state, debris_color_state, shadow_start_color_state, shadow_end_color_state, spermatozoon_scale_slider_state, shadow_offset_slider_state, shadow_scale_slider_state, n_points_render_slider_state], examples_per_page=3)
                        test_frame_button = gr.Button("Generate test frame")
                        
                        with gr.Accordion("Color picking options", open=False):
                            gr.Markdown(" ### Spermatozoon colors")
                            with gr.Row():
                                spermatozoon_head_color = gr.ColorPicker(label="Head", value=spermatozoon_head_color_state.value)
                                spermatozoon_neck_color = gr.ColorPicker(label="Neck", value=spermatozoon_neck_color_state.value)
                                spermatozoon_tail_color = gr.ColorPicker(label="Tail", value=spermatozoon_tail_color_state.value)
                                spermatozoon_droplet_color = gr.ColorPicker(label="Droplet", value=spermatozoon_droplet_color_state.value)
                            gr.Markdown(" ### Shadow an debris colors")
                            with gr.Row():
                                debris_color = gr.ColorPicker(label="Debris", value=debris_color_state.value)
                                shadow_start_color = gr.ColorPicker(label="Shadow start", value=shadow_start_color_state.value)
                                shadow_end_color = gr.ColorPicker(label="Shadow end", value=shadow_end_color_state.value)
                        extract_button.click(process_annotation, [spermatozoon_image_annotator], [spermatozoon_head_color, spermatozoon_neck_color, spermatozoon_tail_color, spermatozoon_droplet_color, debris_color, shadow_start_color, shadow_end_color])
                        with gr.Accordion("Advanced style parameters", open=False):                     
                            gr.Markdown(" ### Scales and other parameters")
                            with gr.Row():
                                spermatozoon_scale_slider = gr.Slider(label="Sperm scale", minimum=0.1, maximum=100, value=spermatozoon_scale_slider_state.value, interactive=True)
                                shadow_offset_slider = gr.Slider(label="Shadow offset", minimum=-10, maximum=10, value=shadow_offset_slider_state.value, interactive=True)
                                shadow_scale_slider = gr.Slider(label="Shadow scale", minimum=0, maximum=10, value=shadow_scale_slider_state.value, interactive=True)
                                n_points_render_slider = gr.Slider(label="N points to render", minimum=10, maximum=1000, value=n_points_render_slider_state.value, interactive=True)
                        
                        #examples_style_item = gr.Examples(examples_style, elem_id="examples-container", label="Style adjustment examples", example_labels=examples_style_names, inputs=[spermatozoon_image_annotator, spermatozoon_head_color, spermatozoon_neck_color, spermatozoon_tail_color, spermatozoon_droplet_color, debris_color, shadow_start_color, shadow_end_color, spermatozoon_scale_slider, shadow_offset_slider, shadow_scale_slider, n_points_render_slider], examples_per_page=3)

                        test_frame_button.click(self._generate_sequence, one_state, background_output)
                        
                        spermatozoon_head_color_state.change(self._pass_value, spermatozoon_head_color_state, spermatozoon_head_color)
                        spermatozoon_neck_color_state.change(self._pass_value, spermatozoon_neck_color_state, spermatozoon_neck_color)
                        spermatozoon_tail_color_state.change(self._pass_value, spermatozoon_tail_color_state, spermatozoon_tail_color)
                        spermatozoon_droplet_color_state.change(self._pass_value, spermatozoon_droplet_color_state, spermatozoon_droplet_color)
                        debris_color_state.change(self._pass_value, debris_color_state, debris_color)
                        shadow_end_color_state.change(self._pass_value, shadow_end_color_state, shadow_end_color)
                        spermatozoon_scale_slider_state.change(self._pass_value, spermatozoon_scale_slider_state, spermatozoon_scale_slider)
                        shadow_offset_slider_state.change(self._pass_value, shadow_offset_slider_state, shadow_offset_slider)
                        shadow_scale_slider_state.change(self._pass_value, shadow_scale_slider_state, shadow_scale_slider)
                        n_points_render_slider_state.change(self._pass_value, n_points_render_slider_state, n_points_render_slider)
                        
                        spermatozoon_head_color.change(self._update_colors, [spermatozoon_head_color, spermatozoon_neck_color, spermatozoon_tail_color, spermatozoon_droplet_color, debris_color, shadow_start_color, shadow_end_color, spermatozoon_scale_slider, shadow_offset_slider, shadow_scale_slider, n_points_render_slider], None)
                        spermatozoon_neck_color.change(self._update_colors, [spermatozoon_head_color, spermatozoon_neck_color, spermatozoon_tail_color, spermatozoon_droplet_color, debris_color, shadow_start_color, shadow_end_color, spermatozoon_scale_slider, shadow_offset_slider, shadow_scale_slider, n_points_render_slider], None)
                        spermatozoon_tail_color.change(self._update_colors, [spermatozoon_head_color, spermatozoon_neck_color, spermatozoon_tail_color, spermatozoon_droplet_color, debris_color, shadow_start_color, shadow_end_color, spermatozoon_scale_slider, shadow_offset_slider, shadow_scale_slider, n_points_render_slider], None)
                        spermatozoon_droplet_color.change(self._update_colors, [spermatozoon_head_color, spermatozoon_neck_color, spermatozoon_tail_color, spermatozoon_droplet_color, debris_color, shadow_start_color, shadow_end_color, spermatozoon_scale_slider, shadow_offset_slider, shadow_scale_slider, n_points_render_slider], None)
                        debris_color_state.change(self._update_colors, [spermatozoon_head_color, spermatozoon_neck_color, spermatozoon_tail_color, spermatozoon_droplet_color, debris_color, shadow_start_color, shadow_end_color, spermatozoon_scale_slider, shadow_offset_slider, shadow_scale_slider, n_points_render_slider], None)
                        shadow_end_color.change(self._update_colors, [spermatozoon_head_color, spermatozoon_neck_color, spermatozoon_tail_color, spermatozoon_droplet_color, debris_color, shadow_start_color, shadow_end_color, spermatozoon_scale_slider, shadow_offset_slider, shadow_scale_slider, n_points_render_slider], None)
                        spermatozoon_scale_slider.change(self._update_colors, [spermatozoon_head_color, spermatozoon_neck_color, spermatozoon_tail_color, spermatozoon_droplet_color, debris_color, shadow_start_color, shadow_end_color, spermatozoon_scale_slider, shadow_offset_slider, shadow_scale_slider, n_points_render_slider], None)
                        shadow_offset_slider.change(self._update_colors, [spermatozoon_head_color, spermatozoon_neck_color, spermatozoon_tail_color, spermatozoon_droplet_color, debris_color, shadow_start_color, shadow_end_color, spermatozoon_scale_slider, shadow_offset_slider, shadow_scale_slider, n_points_render_slider], None)
                        shadow_scale_slider.change(self._update_colors, [spermatozoon_head_color, spermatozoon_neck_color, spermatozoon_tail_color, spermatozoon_droplet_color, debris_color, shadow_start_color, shadow_end_color, spermatozoon_scale_slider, shadow_offset_slider, shadow_scale_slider, n_points_render_slider], None)
                        n_points_render_slider.change(self._update_colors, [spermatozoon_head_color, spermatozoon_neck_color, spermatozoon_tail_color, spermatozoon_droplet_color, debris_color, shadow_start_color, shadow_end_color, spermatozoon_scale_slider, shadow_offset_slider, shadow_scale_slider, n_points_render_slider], None)
                        
            with gr.Accordion("Parameter Selection", open=False):
                with gr.Row():
                    with gr.Group():
                        species_dropdown = gr.Dropdown(choices=self.species_names, label="Species", value=self.starting_specie, allow_custom_value=True)
                        species_json_viewer = gr.JSON(label="Parameters", value=get_species_dict(), open=True)  # JSON viewer for non-custom selections
                        species_json_editor = gr.Textbox(label="Editable parameters", lines=20, visible=False)  # Hidden by default
                        with gr.Column():
                            species_editor_save_text = gr.Textbox(label="Species name", value="Specie", visible=False)
                            species_editor_save_button = gr.Button("Save", visible=False)
                    with gr.Group():
                        morphologies_checkboxes = gr.CheckboxGroup(choices=list(get_species_dict().keys()), interactive=True, label="Morphologies", value=list(get_species_dict().keys())[0])
                        gr.Markdown("### Number of elements")
                        n_spermatozoa = RangeSlider(label="N spermatozoa", minimum=1, maximum=250, value=(120, 220), interactive=True)
                        debris_checkbox = gr.Checkbox(label="Debris rendering", value=True, interactive=True)
                        n_debris = RangeSlider(label="N debris", minimum=0, maximum=500, value=(20, 200), interactive=True)
                        same_probabilities_checkbox = gr.Checkbox(label="Use same probabilities for each class", value=False, interactive=True)
                n_spermatozoa.change(self._update_config, [gr.State("spermatozoon_n"), n_spermatozoa], None)
                n_debris.change(self._update_config, [gr.State("debris_n"), n_debris], None)
                debris_checkbox.change(self._update_config, [gr.State("render_debris"), debris_checkbox], None)
                same_probabilities_checkbox.change(self._update_config, [gr.State("use_same_probabilities"), same_probabilities_checkbox], None)
                
                species_dropdown.change(toggle_components, [species_dropdown, species_json_viewer], [species_dropdown, morphologies_checkboxes, species_json_editor, species_json_viewer, species_editor_save_text, species_editor_save_button])
                species_editor_save_button.click(save_custom_json, [species_json_editor, species_editor_save_text], [species_dropdown])

                            
            with gr.Accordion("Data Generation", open=True):
                gr.Examples(["","",""], elem_id="examples-container", label="Dataset examples", inputs=gr.State(), example_labels=examples_style_names, examples_per_page=3)
                with gr.Row():
                    with gr.Group():
                        gr.Markdown("### Generate test sequence")
                        default_test_image = cv2.imread("/home/daniel/Documents/Projects/Kubus/Morfología/spermatozoon/dataset-v5/frames/seed_000000_0000.png")
                        test_image = gr.Gallery(label="Generated sequence", preview=True, selected_index=0) #value=[self.test_gif_path] + [os.path.join(self.test_sequence_path, p) for p in np.random.choice(os.listdir(self.test_sequence_path), 4)], 
                        generate_test_button = gr.Button()
                        twentyfive_slider = gr.Slider(label="25", value=25, visible=False)
                        generate_test_button.click(self._generate_sequence, twentyfive_slider, test_image)
                    with gr.Group():
                        with gr.Group():
                            gr.Markdown("### Generate synthetic dataset")
                            with gr.Row():
                                dataset_name = gr.Textbox(value="SyntheticDataset", label="Dataset Name", placeholder="Enter the dataset name here")
                                save_folder = gr.Textbox(value=os.getcwd(),label="Save Folder", placeholder="Enter the folder path to save images")
                            with gr.Row():
                                text_n_sequences = gr.Textbox(value="1000", label="Number of sequences", interactive=True)
                                text_n_frames_sequence = gr.Textbox(value="25", label="Number of frames per sequence", interactive=True)
                                text_seed = gr.Textbox(value="42", label="Generator seed", interactive=True)
                            start_button = gr.Button("Start Process")
                            remaining_time_box = gr.Markdown()
                            #remaining_time_box = gr.Textbox(label="Estimated Remaining Time", lines=1, interactive=False)
                            gallery = gr.Gallery(label="Generated Images")
                            #log_box = gr.Textbox(label="Log", lines=3, interactive=False)
                            # Define the function that connects the button to the processing function
                            start_button.click(fn=self._generate_dataset,
                                            inputs=[dataset_name, save_folder, text_n_sequences, text_n_frames_sequence, text_seed],
                                            outputs=[gallery, remaining_time_box])
                

        
    def launch(self):
        self.app.launch(allowed_paths=["/media/daniel/TOSHIBA_EXT"], share=False, debug=True) #, auth=("username", "password"))
    
        
if __name__ == "__main__":
    config_path = os.path.join(os.getcwd(), 'cfg', 'config.ini')
    
    app = App(config_path)
    app.launch()